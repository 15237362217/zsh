# ng plugin

This plugin adds autocompletion support for [Angular's CLI](https://github.com/angular/angular-cli)
(named `ng`).

To use it, add `ng` to the plugins array of your zshrc file:

```zsh
plugins=(... ng)
```
